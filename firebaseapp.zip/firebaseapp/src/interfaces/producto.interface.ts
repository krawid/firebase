export interface IProducto {
  nombre: string;
  precio: number;
}