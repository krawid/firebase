// ProductosPage.tsx

// Para el mantenimiento de datos en Firestore necesitamos importar unas funciones de la librería de Firestore
import {
	collection,
	getDocs,
	doc,
	addDoc,
	setDoc,
	deleteDoc,
	QueryDocumentSnapshot,
	DocumentData
} from 'firebase/firestore';
// hooks React para detectar cambios de estado
import { FormEvent, useEffect, useState } from 'react';
// hook propio para gestionar el formulario
import { useForm } from './hooks/useForm';
// Importación, desde el archivo de configuración de Firebase (firebaseConfig) del objeto db, que es el que el archivo de configuración ha exportado
import * as firebaseConfig from './firebaseConfig';
// Interface para dar tipo al producto
import { IProducto } from './interfaces/producto.interface';

export const ProductosPage = () => {
	// useState que va a gestionar el cambio de estado de nuestra colección de productos
	const [productos, setProductos] = useState<QueryDocumentSnapshot<DocumentData>[]>([]);
	// useState que va a gestionar el cambio de estado de los tiempos de carga (loading) de los productos. Al principio lo ponemos a true para que cargue los datos (ver useEffect)
	const [loading, setLoading] = useState<boolean>(true);
	// useState que va a gestionar el cambio de estado que va a avisar a React de si estamos agregando/modificando (edit-->false/true) un producto. De primeras es false porque al principio, la aplicación está preparada para agregar un producto nuevo
	const [edit, setEdit] = useState<boolean>(false);
	// useState que va a gestionar el cambio de estado del producto que se esté modificando (idEdit)
	const [idEdit, setIdEdit] = useState<boolean>(false);

	// Llamada al hook useForm para gestionar el formulario
	const { form, onInputChange, onSetForm, onResetForm } = useForm<IProducto>({
		nombre: '',
		precio: 0
	});

	// Desestructuración de los valores del formulario para utilizarlos
	const { nombre, precio } = form;

	const saveProducto = async (e: FormEvent) => {
		e.preventDefault();
		if (edit) {
			// Métodos de Firebase
			// doc selecciona el producto a actualizar. De la colección productos, será aquel producto cuyo idEdit sea el que estemos editando. db representa a Firebase
			const productoActualizar = doc(firebaseConfig.db, `productos/${idEdit}`);
			await setDoc(productoActualizar, {
				nombre: nombre,
				precio: precio
			});
			// setLoading(true) va a disparar la recarga de la tabla
			setLoading(true);
		} else {
			// addDoc agrega a la colección (collection) productos de nuestra base de datos (db), el producto con los datos (data) que devuelve el formulario
			await addDoc(collection(firebaseConfig.db, 'productos'), {
				nombre: nombre,
				precio: precio
			});
			// setLoading(true) va a disparar la recarga de la tabla
			setLoading(true);
		}
	};

	// Función de eliminación. Recibimos el producto y lo eliminamos si afirmamos el mensaje de confirmación. También la función va con async porque dentro hay métodos con await
	const deleteProducto = async (producto: DocumentData) => {
		// Preguntamos si estamos seguros
		if (window.confirm(`¿Estás seguro de eliminar ${producto.data().nombre}?`)) {
			// Si estamos seguros, seleccionamos el producto de la misma manera que en el método de actualización. Con doc, seleccionamos de nuestra base de datos (db), el producto cuya id queremos eliminar
			const productoEliminar = doc(firebaseConfig.db, `productos/${producto.id}`);
			// Una vez seleccionado, deleteDoc lo elimina. También es un método asíncrono que devuelve una promesa (await)
			await deleteDoc(productoEliminar);
			// setLoading(true) va a disparar la recarga de la tabla
			setLoading(true);
		}
	};

	// Función que se va a ejecutar cuando pulsamos en el botón de Editar de un producto
	// Recibimos el producto.
	const editProducto = (producto: DocumentData) => {
		// producto.data() tiene los datos del producto, data() es porque la librería de Firebase lo ha puesto en ese método
		console.log(producto.data());
		// Construimos el producto que vamos a pasar al formulario
		const productoEdit: IProducto = {
			nombre: producto.data().nombre,
			precio: producto.data().precio
		};
		// Y aquí lo pasamos
		onSetForm(productoEdit);
		// Almacenamos el id del producto que vamos a actualizar, para que cuando le demos al botón actualizar sepamos qué producto estamos modificando
		setIdEdit(producto.id);
		// Confirmamos la acción de editar
		setEdit(true);
	};

	// Función para cancelar edición. Al poner edit a false avisamos a React de que estamos agregando
	const cancelarEdicion = () => {
		// Borramos la información de los inputs
		onResetForm();
		setEdit(false);
	};

	// useEffect ejecuta un código cuando sus dependencias cambian. Lo utilizamos para cargar los datos de productos. Cada vez que cambie loading y se ponga a true haremos la consulta de datos
	useEffect(() => {
		if (loading) {
			// getProductos va a traer todos los datos de los productos de Firebase.
			// También es una promesa, por lo que necesitamos async/await
			const getProductos = async () => {
				// getDocs es una función de Firebase que trae los datos de una colección (collection), de nuestra base de datos (db), que se llama productos
				const productos = await getDocs(collection(firebaseConfig.db, 'productos'));
				// Pasamos a los productos que va a pintar la tabla los docs. docs también es algo de Firebase. De la colección que hemos conseguido en la línea anterior, extraemos los docs, es decir, los documentos, en nuestro caso los productos
				setProductos(productos.docs);
				setLoading(false);
			};

			getProductos();
		}
	}, [loading]); // Se ejecutará cuando cambie el valor de loading

	return (
		<>
			<div className="container">
				<div className="row mt-4">
					<div className="col">
						<h1>Administrar productos con Firebase</h1>
						<hr />
						{loading && <div className="alert alert-info text-center">Cargando...</div>}
						{!loading && productos.length > 0 && (
							<table className="table table-striped">
								<thead>
									<tr>
										<th scope="col">Nombre</th>
										<th scope="col">Precio</th>
										<th scope="col">Opciones</th>
									</tr>
								</thead>
								<tbody>
									{productos.map((x) => {
										return (
											<tr key={x.id}>
												<td>{x.data().nombre}</td>
												<td>{x.data().precio}</td>
												<td>
													<button className="btn btn-warning" onClick={() => editProducto(x)}>
														Editar
													</button>
													<button className="btn btn-danger" onClick={() => deleteProducto(x)}>
														Eliminar
													</button>
												</td>
											</tr>
										);
									})}
								</tbody>
							</table>
						)}
					</div>
					<div className="col">
						<form onSubmit={saveProducto}>
							<div className="form-group">
								<label className="form-label" htmlFor="nombre">
									Nombre
								</label>
								<input
									id="nombre"
									type="text"
									className="form-control"
									value={nombre}
									onChange={onInputChange}
									required
								/>
							</div>
							<div className="form-group">
								<label className="form-label" htmlFor="precio">
									Precio
								</label>
								<input
									id="precio"
									type="number"
									className="form-control"
									value={precio}
									onChange={onInputChange}
									required
								/>
							</div>

							{/* El botón Cancelar edición solo aparece cuando edit es true */}
							{edit && (
								<button type="button" className="btn btn-secondary mt-2" onClick={cancelarEdicion}>
									Cancelar edición
								</button>
							)}
							<button type="submit" className="btn btn-primary mt-2">
								{edit ? 'Actualizar' : 'Agregar'}
							</button>
						</form>
					</div>
				</div>
			</div>
		</>
	);
};