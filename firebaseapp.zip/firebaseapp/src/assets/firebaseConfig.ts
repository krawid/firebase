// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCUx56gBngDGgN9_PT7NqGCM5Jfsy0PAPg",
  authDomain: "tiempomoi.firebaseapp.com",
  projectId: "tiempomoi",
  storageBucket: "tiempomoi.appspot.com",
  messagingSenderId: "396069992669",
  appId: "1:396069992669:web:6a88c2040ed19719e84334"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
// Creamos algo público para que desde cualquier componente podamos venir aquí y utilizar Firebase. Cada componente que utilice Firebase importará firebaseConfig y utilizará db (podría tener otro nombre) para usar, en este caso, Firestore
export const db = getFirestore(app);